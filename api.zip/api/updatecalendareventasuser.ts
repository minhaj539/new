import { google } from 'googleapis';
import type { NextApiRequest, NextApiResponse } from 'next';

export default async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method !== 'PUT') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const eventData = req.body;

    console.log('REQUEST DATA');
    console.log(eventData);

    const accessToken = eventData.access_token;
    console.log(`TOKEN${accessToken}`);

    const authClient = new google.auth.OAuth2();
    authClient.setCredentials({ access_token: accessToken });

    const calendar = google.calendar({ version: 'v3', auth: authClient });

    const response = await calendar.events.update({
      calendarId: 'primary',
      eventId: eventData.eventId, // Replace with the event ID you want to update
      requestBody: eventData,
    });

    console.log('Event updated:', response.data);

    return res.status(200).json(response.data);
  } catch (error) {
    console.error('Error updating calendar event:', error);

    return res.status(500).json({ error: 'Error updating calendar event' });
  }
};
