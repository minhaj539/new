import { JWT } from 'google-auth-library';
import { google } from 'googleapis';
import type { NextApiRequest, NextApiResponse } from 'next';
import path from 'path';

const keyFilePath = path.resolve(
  process.cwd(),
  './src/googleserviceaccount.json'
);

const jwtClient = new JWT({
  keyFile: keyFilePath,
  scopes: [
    'https://www.googleapis.com/auth/calendar',
    'https://www.googleapis.com/auth/calendar.events',
  ],
  subject: 'vijaya@warpdrivetech.in',
});

const calendar = google.calendar({ version: 'v3', auth: jwtClient });

export default async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method !== 'PUT') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { eventId, eventData } = req.body; // Assuming you send both event ID and updated event data

    const response = await calendar.events.update({
      calendarId: 'primary',
      eventId, // The ID of the event you want to update
      requestBody: eventData, // Updated event data
    });

    console.log('Event updated:', response.data);

    return res.status(200).json(response.data); // Return the response for success
  } catch (error) {
    console.error('Error updating calendar event:', error);

    return res.status(500).json({ error: 'Error updating calendar event' }); // Return the response for error
  }
};
