import { JWT } from 'google-auth-library';
import { google } from 'googleapis';
import type { NextApiRequest, NextApiResponse } from 'next';
import path from 'path';

const keyFilePath = path.resolve(
  process.cwd(),
  './src/googleserviceaccount.json'
);

const jwtClient = new JWT({
  keyFile: keyFilePath,
  scopes: [
    'https://www.googleapis.com/auth/calendar',
    'https://www.googleapis.com/auth/calendar.events',
  ],
  subject: 'vijaya@warpdrivetech.in',
});

const calendarId = 'c_47ellimm6270atjo1k0sovdiq4@group.calendar.google.com';
const calendar = google.calendar({ version: 'v3', auth: jwtClient });

export default async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const eventData = req.body;

    const response = await calendar.events.insert({
      calendarId,
      requestBody: eventData,
    });

    console.log('Event created:', response.data);

    return res.status(200).json(response.data); // Return the response for success
  } catch (error) {
    console.error('Error creating calendar event:', error);

    return res.status(500).json({ error: 'Error creating calendar event' }); // Return the response for error
  }
};
