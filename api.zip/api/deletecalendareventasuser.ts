import { google } from 'googleapis';
import type { NextApiRequest, NextApiResponse } from 'next';

export default async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const eventData = req.body;

    console.log('REQUEST DATA');
    console.log(eventData);

    const accessToken = eventData.access_token;
    console.log(`TOKEN${accessToken}`);

    const authClient = new google.auth.OAuth2();
    authClient.setCredentials({ access_token: accessToken });

    const calendar = google.calendar({ version: 'v3', auth: authClient });

    const response = await calendar.events.delete({
      calendarId: 'primary',
      eventId: eventData.eventId, // Replace with the event ID you want to delete
    });

    console.log('Event deleted:', response.data);

    return res.status(204).end(); // Return a success response with no content
  } catch (error) {
    console.error('Error deleting calendar event:', error);

    return res.status(500).json({ error: 'Error deleting calendar event' });
  }
};
