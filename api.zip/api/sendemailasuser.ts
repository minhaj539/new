import { google } from 'googleapis';
import type { NextApiRequest, NextApiResponse } from 'next';

export default async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const emailData = req.body;

    console.log('REQUEST DATA');
    console.log(emailData);

    const emailLines = [
      `From: ${emailData.from}`,
      `To: ${emailData.to}`,
      `Subject: ${emailData.subject}`,
      '',
      emailData.body,
    ];

    const email = emailLines.join('\r\n');

    const base64EncodedEmail = Buffer.from(email).toString('base64');

    const accessToken = emailData.access_token;
    console.log(`TOKEN${accessToken}`);

    const authClient = new google.auth.OAuth2();
    authClient.setCredentials({ access_token: accessToken });

    const gmail = google.gmail({ version: 'v1', auth: authClient });

    const response = await gmail.users.messages.send({
      userId: 'vijaya@warpdrivetech.in',
      requestBody: {
        raw: base64EncodedEmail,
      },
    });

    console.log('Email sent:', response.data);

    return res.status(200).json(response.data);
  } catch (error) {
    console.error('Error sending email:', error);
    return res.status(500).json({ error: 'Error sending email' });
  }
};
