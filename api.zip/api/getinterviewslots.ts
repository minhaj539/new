/* eslint-disable import/no-extraneous-dependencies */
import { JWT } from 'google-auth-library';
import { google } from 'googleapis';
import type { NextApiRequest, NextApiResponse } from 'next';
import path from 'path';

const keyFilePath = path.resolve(
  process.cwd(),
  './src/googleserviceaccount.json'
);

const jwtClient = new JWT({
  keyFile: keyFilePath, // 'C:/Users/HP/Documents/Scotty/scotty/src/googleserviceaccount.json',
  scopes: [
    'https://www.googleapis.com/auth/calendar',
    'https://www.googleapis.com/auth/calendar.events',
  ],
  subject: 'vijaya@warpdrivetech.in', // Specify the email address of the user to impersonate
});

const calendar = google.calendar({ version: 'v3', auth: jwtClient });

export default async (_req: NextApiRequest, res: NextApiResponse) => {
  try {
    // You can modify these parameters to customize the events you want to fetch
    console.log('GET CALENDAR EVENTS');
    const calendarId = 'c_47ellimm6270atjo1k0sovdiq4@group.calendar.google.com'; // Use 'primary' for the user's primary calendar
    const timeMin = new Date().toISOString(); // Start fetching from the current time

    const response = await calendar.events.list({
      calendarId,
      timeMin,
      maxResults: 10, // Maximum number of events to fetch
      singleEvents: true,
      orderBy: 'startTime',
    });
    console.log('EVENTS');
    console.log(response);
    const events = response.data.items || [];

    console.log(events);
    return res.status(200).json(events);
  } catch (error) {
    console.error('Error fetching calendar events:', error);
    return res.status(500).json({ error: 'Error fetching calendar events' });
  }
};
